<template>
    <div class="d-flex align-items-center">
        <h6 class="mx-3">Login</h6>
        <button class="btn"><h6 class="mx-3">Register</h6></button>
    </div>
</template>

<style>
    .btn {
        color: white;
        background-color: orange;
        border-radius: 100px;
        padding-top: 9px;
    }
    .btn:hover {
        color: black;
        background-color: white;
    }
</style>