<template>
    <div class="d-flex justify-content-evenly">
        <h6 class="mx-3">Home</h6>
        <h6 class="mx-3"><span style="color: orange;">Order</span></h6>
        <h6 class="mx-3">About</h6>
        <h6 class="mx-3">Blog</h6>
        <h6 class="mx-3">Contact Us</h6>
    </div>
</template>