<template>
  <div>
    <web-header></web-header>
    <home-page></home-page>
    <web-footer></web-footer>
  </div>
</template>

<script setup>
import WebHeader from './components/header/WebHeader.vue';
import HomePage from './components/pages/HomePage.vue';
import WebFooter from './components/footer/WebFooter.vue';
</script>
