import { createStore } from "vuex";
import pizza from './pizza';

export default createStore({
  modules: {
    pizza,
  },
});
